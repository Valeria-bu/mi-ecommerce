# E-Commerce - Práctica Code Together

## 🎯 Descripción del Proyecto

Este es un proyecto de e-commerce desarrollado con HTML, CSS y JavaScript puro. Incluye todas las funcionalidades requeridas para la práctica.

## ✨ Funcionalidades Implementadas

### 1. **Menú Lateral** ✅
- Botón de hamburguesa en el header (lado izquierdo) que abre un menú lateral
- Menú lateral con navegación (Inicio, Productos, Contacto, Beneficios)
- Botón "X" para cerrar el menú
- Se cierra automáticamente al:
  - Hacer clic en un enlace del menú
  - Hacer clic fuera del menú
  - Hacer clic en el botón X

### 2. **Badge del Carrito** ✅
- Badge rojo con el número de productos en el carrito
- Se actualiza automáticamente al agregar/eliminar productos
- Los datos persisten en el navegador (localStorage)

### 3. **Botón "Agregar al Carrito"** ✅
- Debajo del precio de cada producto
- Al hacer clic:
  - Agrega el producto al carrito
  - Incrementa el contador en el badge
  - Muestra un mensaje de confirmación

### 4. **Funcionalidad Libre - Modal de Carrito Mejorado** ✅
- Modal elegante al hacer clic en el icono del carrito
- Muestra:
  - Lista de productos con precios
  - Botón "×" para eliminar cada producto
  - Total del carrito
  - Botón "Vaciar Carrito"
- Funcionalidades:
  - Eliminar productos individuales
  - Vaciar todo el carrito
  - Cerrar modal al hacer clic fuera o en el botón X

## 📁 Estructura del Proyecto

```
e-commerce/
├── index.html              # Página de inicio
├── productos.html          # Página de productos
├── css/
│   ├── styles.css         # Estilos principales
│   └── productos.css      # Estilos de productos (si existe)
├── JavaScript/
│   └── scripts.js         # Lógica de JavaScript
├── img/                   # Imágenes de productos
├── README.md              # Este archivo
└── firebase.json          # Configuración Firebase
```

## 🚀 Cómo Usar

1. **Abrir el proyecto:**
   - Abre `index.html` en tu navegador

2. **Menú Lateral:**
   - Haz clic en el icono de hamburguesa (≡) para abrir el menú
   - Haz clic en un enlace para navegar y cerrar automáticamente
   - O haz clic en la "X" para cerrarlo manualmente

3. **Agregar Productos al Carrito:**
   - Ve a la página de "Productos"
   - Haz clic en "Agregar al carrito" en cualquier producto
   - Verás el badge del carrito incrementarse

4. **Ver Carrito:**
   - Haz clic en el icono del carrito (🛒) en el header
   - Se abrirá un modal elegante con tu carrito
   - Puedes eliminar productos o vaciar todo

## 💾 Persistencia de Datos

El carrito se guarda en el `localStorage` del navegador, lo que significa:
- Los productos se mantienen aunque cierres la pestaña
- Los datos se borran si limpias el caché/datos del navegador

## 🎨 Diseño

- **Colores:** Paleta de purpura, rosa y naranja
- **Tipografía:** Segoe UI, Tahoma, Geneva, Verdana
- **Diseño Responsivo:** Optimizado para desktop y móvil
- **Animaciones:** Transiciones suaves en botones y menú

## 📱 Compatibilidad

- ✅ Chrome, Firefox, Safari, Edge
- ✅ Dispositivos móviles
- ✅ Tablets
- ✅ Pantallas de escritorio

## 🔧 Tecnologías Utilizadas

- **HTML5** - Estructura
- **CSS3** - Estilos y animaciones
- **JavaScript Vanilla** - Funcionalidad sin frameworks
- **localStorage API** - Persistencia de datos

## 📝 Notas para la Entrega

Este proyecto cumple con todos los requisitos de la práctica:

1. ✅ Menú lateral con hamburguesa y X
2. ✅ Badge del carrito visible
3. ✅ Botones "Agregar al carrito"
4. ✅ Funcionalidad libre: Modal mejorado del carrito

## 👨‍💻 Autor

Proyecto de práctica - Code Together

---

**¡Listo para entregar! 🎉**

Comprime todo el directorio `e-commerce` en un archivo `.zip` y cárgalo en la plataforma EBAC.
